// Get elements from the page
const urlInput    = document.getElementById("url");
const sizeSelect  = document.getElementById("size");
const generateBtn = document.getElementById("generate-btn");
const copyBtn     = document.getElementById("copy-btn");
const spinner     = document.getElementById("spinner");
const qrContainer = document.getElementById("qr-container");
const qrImage     = document.getElementById("qr-image");
const downloadBtn = document.getElementById("download-btn");

// When "Generate QR Code" is clicked
generateBtn.addEventListener("click", () => {
  const url  = urlInput.value.trim();
  const size = sizeSelect.value;

  // Check if the user entered a URL
  if (!url) {
    alert("Please enter a valid URL.");
    return;
  }

  // Show loading spinner, hide QR image
  qrContainer.classList.add("hidden");
  spinner.classList.remove("hidden");

  // Create QR Code URL using API
  const qrURL = `https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(url)}&size=${size}x${size}`;

  // Set image source
  qrImage.src = qrURL;

  // When image is done loading, show it
  qrImage.onload = () => {
    spinner.classList.add("hidden");
    qrContainer.classList.remove("hidden");
    downloadBtn.href = qrURL; // Set download link
  };
});

// When "Copy URL" is clicked
copyBtn.addEventListener("click", () => {
  const url = urlInput.value.trim();

  if (!url) {
    alert("Enter a URL first so I can copy it.");
    return;
  }

  // Try copying to clipboard
  navigator.clipboard.writeText(url)
    .then(() => alert("URL copied to clipboard! ✔️"))
    .catch(() => alert("Failed to copy URL 😢"));
});
